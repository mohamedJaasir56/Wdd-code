<?php
require 'config.php';

echo "<h2>Database Structure Check</h2>";

// Check customers table
echo "<h3>Customers Table:</h3>";
$result = $conn->query("DESCRIBE customers");
if ($result) {
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>{$row['Field']} - {$row['Type']}</li>";
    }
    echo "</ul>";
} else {
    echo "Customers table doesn't exist or error: " . $conn->error;
}

// Check orders table
echo "<h3>Orders Table:</h3>";
$result = $conn->query("DESCRIBE orders");
if ($result) {
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>{$row['Field']} - {$row['Type']}</li>";
    }
    echo "</ul>";
} else {
    echo "Orders table doesn't exist or error: " . $conn->error;
}

// Check order_items table
echo "<h3>Order Items Table:</h3>";
$result = $conn->query("DESCRIBE order_items");
if ($result) {
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>{$row['Field']} - {$row['Type']}</li>";
    }
    echo "</ul>";
} else {
    echo "Order_items table doesn't exist or error: " . $conn->error;
}
?>