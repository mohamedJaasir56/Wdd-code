<?php
require 'config.php';

// Add a test item to cart for testing
$_SESSION['cart'] = [
    1 => [
        'id' => 1,
        'name' => 'Test Product',
        'price' => 10.00,
        'image_path' => 'uploads/test.jpg',
        'quantity' => 1
    ]
];

echo "Test item added to cart. <a href='cart.php'>View Cart</a>";
?>