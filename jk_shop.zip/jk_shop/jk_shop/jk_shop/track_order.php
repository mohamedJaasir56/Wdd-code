<?php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tracking_number'])) {
    $tracking_number = sanitizeInput($_POST['tracking_number']);
    
    // Try to find order by ID first, then by any tracking number field if it exists
    $stmt = $conn->prepare("
        SELECT o.*, c.name as customer_name, c.email as customer_email 
        FROM orders o 
        LEFT JOIN customers c ON o.customer_id = c.id 
        WHERE o.id = ? OR o.tracking_number = ?
    ");
    $stmt->bind_param("ss", $tracking_number, $tracking_number);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($order = $result->fetch_assoc()) {
        // Get order items
        $items_stmt = $conn->prepare("
            SELECT oi.*, p.name as product_name 
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ");
        $items_stmt->bind_param("i", $order['id']);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        
        $items = [];
        $calculated_total = 0;
        while ($item = $items_result->fetch_assoc()) {
            $items[] = $item;
            $calculated_total += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
        }
        
        // Determine status message and progress
        $status = $order['status'] ?? 'pending';
        $status_messages = [
            'pending' => 'Order received and being processed',
            'processing' => 'Order is being prepared',
            'shipped' => 'Order has been shipped',
            'delivered' => 'Order has been delivered',
            'cancelled' => 'Order has been cancelled'
        ];
        
        $progress_percentage = [
            'pending' => 25,
            'processing' => 50,
            'shipped' => 75,
            'delivered' => 100,
            'cancelled' => 0
        ];
        
        echo json_encode([
            'success' => true,
            'order_id' => $order['id'],
            'status' => $status,
            'status_message' => $status_messages[$status] ?? 'Unknown status',
            'progress' => $progress_percentage[$status] ?? 0,
            'customer_name' => $order['customer_name'] ?? 'Unknown',
            'total_amount' => $calculated_total,
            'order_date' => $order['order_date'] ?? date('Y-m-d'),
            'items' => $items
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Order not found. Please check your order ID.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
}
?>