<?php 
require 'config.php';

if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Invalid CSRF token");
    }

    if (isset($_POST['add_supplier'])) {
        $name = sanitizeInput($_POST['name']);
        $email = sanitizeInput($_POST['email']);
        $phone = sanitizeInput($_POST['phone']);
        $address = sanitizeInput($_POST['address']);

        $stmt = $conn->prepare("INSERT INTO suppliers (name, email, phone, address) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $address);
        if ($stmt->execute()) {
            $message = "Supplier added successfully!";
        } else {
            $error = "Error adding supplier";
        }
    } elseif (isset($_POST['delete_supplier'])) {
        $supplier_id = (int)$_POST['supplier_id'];
        
        $stmt = $conn->prepare("DELETE FROM suppliers WHERE id = ?");
        $stmt->bind_param("i", $supplier_id);
        if ($stmt->execute()) {
            $message = "Supplier deleted successfully!";
        } else {
            $error = "Error deleting supplier";
        }
    }
}

// Get all suppliers
$suppliers = $conn->query("SELECT * FROM suppliers ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Supplier Management - Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="admin-nav">
        <div class="brand">JK Shop Admin</div>
        <ul class="nav-links">
            <li><a href="admin.php">Product Management</a></li>
            <li><a href="customer_management.php">Customer Management</a></li>
            <li><a href="supplier_management.php" class="active">Supplier Management</a></li>
            <li><a href="order_history.php">Customer Order History</a></li>
        </ul>
        <a href="logout.php" class="logout">Logout</a>
    </nav>

    <div class="admin-container">
        <?php if ($message): ?>
            <div class="success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <div class="supplier-form">
            <h2>Add New Supplier</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                
                <div class="form-group">
                    <label>Supplier Name:</label>
                    <input type="text" name="name" required>
                </div>
                
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone:</label>
                    <input type="text" name="phone" required>
                </div>
                
                <div class="form-group">
                    <label>Address:</label>
                    <textarea name="address" required></textarea>
                </div>
                
                <button type="submit" name="add_supplier">Add Supplier</button>
            </form>
        </div>

        <div class="supplier-list">
            <h2>Manage Suppliers</h2>
            
            <?php if ($suppliers->num_rows > 0): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Added</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($supplier = $suppliers->fetch_assoc()): ?>
                        <tr>
                            <td><?= $supplier['id'] ?></td>
                            <td><?= htmlspecialchars($supplier['name']) ?></td>
                            <td><?= htmlspecialchars($supplier['email']) ?></td>
                            <td><?= htmlspecialchars($supplier['phone']) ?></td>
                            <td><?= htmlspecialchars($supplier['address']) ?></td>
                            <td><?= date('Y-m-d', strtotime($supplier['created_at'] ?? 'now')) ?></td>
                            <td>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this supplier?')">
                                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                                    <input type="hidden" name="supplier_id" value="<?= $supplier['id'] ?>">
                                    <button type="submit" name="delete_supplier" class="delete-btn">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No suppliers found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>