<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jk ShOP</title>
    <link rel="icon" href="screwdriver.png">
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Keep existing head content -->
</head>
<body>
<nav class="navbar">
        <div class="logo">
            <a href="#">⚒ JK ShOP</a>
        </div>
        <ul class="menu" id="menu">
            <li><a href="#">Home</a></li>
            <li><a href="#">Shop</a></li>
            <li><a href="#">Categories</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Search products...">
            <button><i class="fas fa-search"></i></button>
        </div>
        <div class="icons">
            <a href="cart.php" class="cart-icon">
                <i class="fas fa-shopping-cart"></i>
                <span id="cart-count" class="cart-count">0</span>
            </a>
            <a href="#"><i class="fas fa-user"></i></a>
            <a href="#"><i class="fas fa-heart"></i></a>
        </div>
        <div class="menu-toggle" id="mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to JK ShOP</h1>
            <p>Your one-stop shop for all your hardware needs.</p>
            <a href="#" class="btn">Shop Now</a>
        </div>
    </section>
    <!-- Keep existing navigation -->

    <section class="order-tracking">
        <div class="container">
            <h2>Track Your Order</h2>
            <p class="tracking-subtitle">Enter your order ID to get real-time updates</p>
            
            <div class="tracking-form-container">
                <form id="tracking-form">
                    <div class="input-group">
                        <i class="fas fa-search"></i>
                        <input type="text" id="tracking-number" placeholder="Enter Order ID (e.g., 1, 2, 3...)" required>
                        <button type="submit">
                            <i class="fas fa-shipping-fast"></i>
                            Track Order
                        </button>
                    </div>
                </form>
            </div>
            
            <div id="tracking-result" class="tracking-result" style="display: none;">
                <div class="order-info">
                    <h3>Order Details</h3>
                    <div class="order-summary">
                        <div class="order-detail">
                            <span class="label">Order ID:</span>
                            <span id="order-id"></span>
                        </div>
                        <div class="order-detail">
                            <span class="label">Customer:</span>
                            <span id="customer-name"></span>
                        </div>
                        <div class="order-detail">
                            <span class="label">Total Amount:</span>
                            <span id="total-amount"></span>
                        </div>
                        <div class="order-detail">
                            <span class="label">Order Date:</span>
                            <span id="order-date"></span>
                        </div>
                    </div>
                </div>
                
                <div class="status-container">
                    <h4>Order Status</h4>
                    <div class="status-message">
                        <i id="status-icon" class="fas fa-clock"></i>
                        <span id="status-text"></span>
                    </div>
                    
                    <div class="progress-container">
                        <div class="progress-bar">
                            <div id="progress-fill" class="progress-fill"></div>
                        </div>
                        <div class="progress-steps">
                            <div class="step" data-step="pending">
                                <i class="fas fa-receipt"></i>
                                <span>Pending</span>
                            </div>
                            <div class="step" data-step="processing">
                                <i class="fas fa-cogs"></i>
                                <span>Processing</span>
                            </div>
                            <div class="step" data-step="shipped">
                                <i class="fas fa-truck"></i>
                                <span>Shipped</span>
                            </div>
                            <div class="step" data-step="delivered">
                                <i class="fas fa-check-circle"></i>
                                <span>Delivered</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div id="order-items" class="order-items">
                    <h4>Order Items</h4>
                    <div id="items-list"></div>
                </div>
            </div>
            
            <div id="tracking-error" class="tracking-error" style="display: none;">
                <i class="fas fa-exclamation-triangle"></i>
                <p id="error-message"></p>
            </div>
        </div>
    </section>

    <div class="product-grid">
        <?php
        $result = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
        while($row = $result->fetch_assoc()): ?>
        <div class="product-card">
            <img src="<?= $row['image_path'] ?>" alt="<?= $row['name'] ?>">
            <h3><?= $row['name'] ?></h3>
            <p>Rs.<?= number_format($row['price'], 2) ?>/=</p>
            <button onclick="addToCart(<?= $row['id'] ?>, '<?= addslashes($row['name']) ?>')" class="add-to-cart-btn">
                <i class="fas fa-cart-plus"></i> Add to Cart
            </button>
        </div>
        <?php endwhile; ?>
    </div>

    <!-- Keep rest of the existing code -->

    <script>
        document.getElementById('tracking-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const trackingNumber = document.getElementById('tracking-number').value;
            const resultDiv = document.getElementById('tracking-result');
            const errorDiv = document.getElementById('tracking-error');
            
            // Hide previous results
            resultDiv.style.display = 'none';
            errorDiv.style.display = 'none';

            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Tracking...';
            submitBtn.disabled = true;

            fetch('track_order.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'tracking_number=' + encodeURIComponent(trackingNumber)
            })
            .then(response => response.json())
            .then(data => {
                // Reset button
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;

                if (data.success) {
                    // Update order details
                    document.getElementById('order-id').textContent = data.order_id;
                    document.getElementById('customer-name').textContent = data.customer_name;
                    document.getElementById('total-amount').textContent = `Rs.${parseFloat(data.total_amount).toFixed(2)}/=`;
                    document.getElementById('order-date').textContent = data.order_date;
                    
                    // Update status
                    const statusText = document.getElementById('status-text');
                    const statusIcon = document.getElementById('status-icon');
                    statusText.textContent = data.status_message;
                    
                    // Update status icon based on status
                    const statusIcons = {
                        'pending': 'fas fa-clock',
                        'processing': 'fas fa-cogs',
                        'shipped': 'fas fa-truck',
                        'delivered': 'fas fa-check-circle',
                        'cancelled': 'fas fa-times-circle'
                    };
                    statusIcon.className = statusIcons[data.status] || 'fas fa-clock';
                    
                    // Update progress bar
                    const progressFill = document.getElementById('progress-fill');
                    progressFill.style.width = data.progress + '%';
                    
                    // Update progress steps
                    const steps = document.querySelectorAll('.step');
                    const statusOrder = ['pending', 'processing', 'shipped', 'delivered'];
                    const currentIndex = statusOrder.indexOf(data.status);
                    
                    steps.forEach((step, index) => {
                        step.classList.remove('active', 'completed');
                        if (index < currentIndex) {
                            step.classList.add('completed');
                        } else if (index === currentIndex) {
                            step.classList.add('active');
                        }
                    });
                    
                    // Update order items
                    const itemsList = document.getElementById('items-list');
                    if (data.items && data.items.length > 0) {
                        itemsList.innerHTML = data.items.map(item => `
                            <div class="item">
                                <span class="item-name">${item.product_name || 'Unknown Product'}</span>
                                <span class="item-details">Qty: ${item.quantity} × Rs.${parseFloat(item.price).toFixed(2)}</span>
                                <span class="item-total">Rs.${(parseFloat(item.price) * parseInt(item.quantity)).toFixed(2)}/=</span>
                            </div>
                        `).join('');
                    } else {
                        itemsList.innerHTML = '<p>No items found for this order.</p>';
                    }
                    
                    resultDiv.style.display = 'block';
                } else {
                    document.getElementById('error-message').textContent = data.message;
                    errorDiv.style.display = 'block';
                }
            })
            .catch(error => {
                // Reset button
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                
                console.error('Error:', error);
                document.getElementById('error-message').textContent = 'Error tracking order. Please try again.';
                errorDiv.style.display = 'block';
            });
        });

        function addToCart(productId, productName) {
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_id=${productId}&quantity=1`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update cart count
                    document.getElementById('cart-count').textContent = data.cart_count;
                    
                    // Show success message
                    showNotification(`${productName} added to cart!`, 'success');
                } else {
                    showNotification('Error adding product to cart', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Error adding product to cart', 'error');
            });
        }

        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.classList.add('show');
            }, 100);
            
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
        }

        // Load cart count on page load
        window.addEventListener('load', function() {
            fetch('get_cart_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('cart-count').textContent = data.cart_count;
                    }
                })
                .catch(error => console.error('Error loading cart count:', error));
        });
    </script>
</body>
</html>
