<?php 
require 'config.php';

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if (!$order_id) {
    header('Location: index.php');
    exit;
}

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, c.name as customer_name, c.email as customer_email 
    FROM orders o 
    LEFT JOIN customers c ON o.customer_id = c.id 
    WHERE o.id = ?
");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order) {
    header('Location: index.php');
    exit;
}

// Calculate order total
$items_stmt = $conn->prepare("
    SELECT oi.*, p.name as product_name 
    FROM order_items oi 
    LEFT JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
");
$items_stmt->bind_param("i", $order_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();

$order_total = 0;
while ($item = $items_result->fetch_assoc()) {
    $order_total += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Confirmation - JK Shop</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .success-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            text-align: center;
        }
        .success-card {
            background: white;
            padding: 50px 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .success-icon {
            font-size: 4rem;
            color: #10b981;
            margin-bottom: 20px;
        }
        .order-id {
            font-size: 2rem;
            color: #667eea;
            font-weight: bold;
            margin: 20px 0;
        }
        .order-details {
            background: #f8f9ff;
            padding: 20px;
            border-radius: 10px;
            margin: 30px 0;
            text-align: left;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .detail-row:last-child {
            margin-bottom: 0;
            font-weight: bold;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .tracking-info {
            background: #e7f3ff;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 4px solid #667eea;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <a href="index.php">⚒ JK ShOP</a>
        </div>
        <ul class="menu">
            <li><a href="index.php">Home</a></li>
        </ul>
    </nav>

    <div class="success-container">
        <div class="success-card">
            <i class="fas fa-check-circle success-icon"></i>
            <h1>Order Placed Successfully!</h1>
            <p>Thank you for your order. We've received your order and will process it shortly.</p>
            
            <div class="order-id">
                Order ID: #<?= $order['id'] ?>
            </div>
            
            <div class="order-details">
                <h3>Order Details</h3>
                <div class="detail-row">
                    <span>Customer:</span>
                    <span><?= htmlspecialchars($order['customer_name']) ?></span>
                </div>
                <div class="detail-row">
                    <span>Email:</span>
                    <span><?= htmlspecialchars($order['customer_email']) ?></span>
                </div>
                <div class="detail-row">
                    <span>Order Date:</span>
                    <span><?= date('F j, Y g:i A', strtotime($order['order_date'])) ?></span>
                </div>
                <div class="detail-row">
                    <span>Status:</span>
                    <span style="color: #f59e0b; font-weight: bold;">Pending</span>
                </div>
                <div class="detail-row">
                    <span>Total Amount:</span>
                    <span>Rs.<?= number_format($order_total, 2) ?>/=</span>
                </div>
            </div>
            
            <div class="tracking-info">
                <h4><i class="fas fa-info-circle"></i> Track Your Order</h4>
                <p>You can track your order status anytime using your Order ID: <strong>#<?= $order['id'] ?></strong></p>
                <p>Go to our homepage and use the Order Tracking section.</p>
            </div>
            
            <div style="margin-top: 30px;">
                <a href="index.php#order-tracking" class="btn btn-primary">
                    <i class="fas fa-search"></i> Track This Order
                </a>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-home"></i> Continue Shopping
                </a>
            </div>
        </div>
    </div>

    <script>
        // Auto-fill tracking form if coming from order success
        window.addEventListener('load', function() {
            if (window.location.hash === '#order-tracking') {
                setTimeout(function() {
                    const trackingInput = document.getElementById('tracking-number');
                    if (trackingInput) {
                        trackingInput.value = '<?= $order['id'] ?>';
                        trackingInput.focus();
                    }
                }, 500);
            }
        });
    </script>
</body>
</html>