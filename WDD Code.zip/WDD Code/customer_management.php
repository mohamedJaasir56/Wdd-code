<?php 
require 'config.php';

if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Invalid CSRF token");
    }

    if (isset($_POST['delete_customer'])) {
        $customer_id = (int)$_POST['customer_id'];
        
        $stmt = $conn->prepare("DELETE FROM customers WHERE id = ?");
        $stmt->bind_param("i", $customer_id);
        if ($stmt->execute()) {
            $message = "Customer deleted successfully!";
        } else {
            $error = "Error deleting customer";
        }
    }
}

// Get all customers
$customers = $conn->query("SELECT * FROM customers ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Management - Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="admin-nav">
        <div class="brand">JK Shop Admin</div>
        <ul class="nav-links">
            <li><a href="admin.php">Product Management</a></li>
            <li><a href="customer_management.php" class="active">Customer Management</a></li>
            <li><a href="supplier_management.php">Supplier Management</a></li>
            <li><a href="order_history.php">Customer Order History</a></li>
        </ul>
        <a href="logout.php" class="logout">Logout</a>
    </nav>

    <div class="admin-container">
        <?php if ($message): ?>
            <div class="success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <div class="customer-list">
            <h2>Customer Management</h2>
            
            <?php if ($customers->num_rows > 0): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($customer = $customers->fetch_assoc()): ?>
                        <tr>
                            <td><?= $customer['id'] ?></td>
                            <td><?= htmlspecialchars($customer['name'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($customer['email'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($customer['phone'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($customer['address'] ?? 'N/A') ?></td>
                            <td><?= date('Y-m-d', strtotime($customer['created_at'] ?? 'now')) ?></td>
                            <td>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this customer?')">
                                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                                    <input type="hidden" name="customer_id" value="<?= $customer['id'] ?>">
                                    <button type="submit" name="delete_customer" class="delete-btn">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No customers found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>