<?php 
require 'config.php';

$message = '';
$error = '';

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// Calculate cart total
$cart_total = 0;
foreach ($_SESSION['cart'] as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}

// Handle checkout form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['place_order'])) {
    $customer_name = sanitizeInput($_POST['customer_name']);
    $customer_email = sanitizeInput($_POST['customer_email']);
    $customer_phone = sanitizeInput($_POST['customer_phone']);
    $customer_address = sanitizeInput($_POST['customer_address']);
    
    if (empty($customer_name) || empty($customer_email) || empty($customer_phone) || empty($customer_address)) {
        $error = "Please fill in all required fields.";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert or get customer
            $stmt = $conn->prepare("SELECT id FROM customers WHERE email = ?");
            $stmt->bind_param("s", $customer_email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($customer = $result->fetch_assoc()) {
                $customer_id = $customer['id'];
            } else {
                // Insert new customer - using only basic columns that should exist
                $stmt = $conn->prepare("INSERT INTO customers (name, email) VALUES (?, ?)");
                $stmt->bind_param("ss", $customer_name, $customer_email);
                $stmt->execute();
                $customer_id = $conn->insert_id;
            }
            
            // Insert order - using only basic columns that exist
            $stmt = $conn->prepare("INSERT INTO orders (customer_id) VALUES (?)");
            $stmt->bind_param("i", $customer_id);
            $stmt->execute();
            $order_id = $conn->insert_id;
            
            // Insert order items
            foreach ($_SESSION['cart'] as $item) {
                $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
                $stmt->execute();
            }
            
            // Commit transaction
            $conn->commit();
            
            // Clear cart
            $_SESSION['cart'] = [];
            
            // Redirect to success page with order ID
            header("Location: order_success.php?order_id=" . $order_id);
            exit;
            
        } catch (Exception $e) {
            // Rollback transaction
            $conn->rollback();
            $error = "Error placing order: " . $e->getMessage() . ". Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout - JK Shop</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .checkout-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 30px;
        }
        .checkout-form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .order-summary {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            height: fit-content;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
        }
        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .order-item:last-child {
            border-bottom: none;
        }
        .item-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .item-image {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 5px;
        }
        .total-row {
            font-weight: bold;
            font-size: 1.2rem;
            color: #667eea;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid #667eea;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            width: 100%;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        @media (max-width: 768px) {
            .checkout-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <a href="index.php">⚒ JK ShOP</a>
        </div>
        <ul class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="checkout.php" class="active">Checkout</a></li>
        </ul>
    </nav>

    <div class="checkout-container">
        <div class="checkout-form">
            <h2><i class="fas fa-credit-card"></i> Checkout</h2>
            
            <?php if ($error): ?>
                <div class="error" style="padding: 15px; background: #f8d7da; color: #721c24; border-radius: 5px; margin-bottom: 20px;">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="customer_name">Full Name *</label>
                    <input type="text" id="customer_name" name="customer_name" required value="<?= $_POST['customer_name'] ?? '' ?>">
                </div>

                <div class="form-group">
                    <label for="customer_email">Email Address *</label>
                    <input type="email" id="customer_email" name="customer_email" required value="<?= $_POST['customer_email'] ?? '' ?>">
                </div>

                <div class="form-group">
                    <label for="customer_phone">Phone Number *</label>
                    <input type="tel" id="customer_phone" name="customer_phone" required value="<?= $_POST['customer_phone'] ?? '' ?>">
                </div>

                <div class="form-group">
                    <label for="customer_address">Delivery Address *</label>
                    <textarea id="customer_address" name="customer_address" rows="3" required><?= $_POST['customer_address'] ?? '' ?></textarea>
                </div>

                <button type="submit" name="place_order" class="btn btn-primary">
                    <i class="fas fa-check"></i> Place Order - Rs.<?= number_format($cart_total, 2) ?>/=
                </button>
            </form>
        </div>

        <div class="order-summary">
            <h3><i class="fas fa-receipt"></i> Order Summary</h3>
            
            <?php foreach ($_SESSION['cart'] as $item): ?>
            <div class="order-item">
                <div class="item-info">
                    <img src="<?= $item['image_path'] ?>" alt="<?= $item['name'] ?>" class="item-image">
                    <div>
                        <div><?= htmlspecialchars($item['name']) ?></div>
                        <small>Qty: <?= $item['quantity'] ?></small>
                    </div>
                </div>
                <div>Rs.<?= number_format($item['price'] * $item['quantity'], 2) ?>/=</div>
            </div>
            <?php endforeach; ?>
            
            <div class="order-item total-row">
                <div>Total Amount:</div>
                <div>Rs.<?= number_format($cart_total, 2) ?>/=</div>
            </div>
        </div>
    </div>
</body>
</html>