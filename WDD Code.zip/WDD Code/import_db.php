<?php
// Database import script
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jk_shop";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully or already exists.\n";
} else {
    echo "Error creating database: " . $conn->error . "\n";
}

// Select the database
$conn->select_db($dbname);

// Read and execute the SQL file
$sql_file = 'mysql jk databace/jk_shop.sql';
if (file_exists($sql_file)) {
    $sql_content = file_get_contents($sql_file);

    // Split the SQL file into individual statements
    $statements = array_filter(array_map('trim', explode(';', $sql_content)));

    foreach ($statements as $statement) {
        if (!empty($statement) && !preg_match('/^--/', $statement)) {
            if ($conn->query($statement) === TRUE) {
                echo "Executed: " . substr($statement, 0, 50) . "...\n";
            } else {
                echo "Error executing: " . $conn->error . "\n";
            }
        }
    }

    echo "Database import completed.\n";
} else {
    echo "SQL file not found: $sql_file\n";
}

$conn->close();
?>
