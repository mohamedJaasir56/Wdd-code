<?php
require 'config.php';

if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Invalid CSRF token");
    }

    if (isset($_POST['update_status'])) {
        $order_id = (int)$_POST['order_id'];
        $status = sanitizeInput($_POST['status']);

        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $order_id);
        if ($stmt->execute()) {
            $message = "Order status updated successfully!";
        } else {
            $error = "Error updating order status";
        }
    }
}

// Get all orders with customer information
$orders_query = "
    SELECT o.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone
    FROM orders o 
    LEFT JOIN customers c ON o.customer_id = c.id 
    ORDER BY o.id DESC
";
$orders = $conn->query($orders_query);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Customer Order History - Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .order-details {
            background: #f9f9f9;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }

        .order-items {
            margin-top: 10px;
        }

        .status-select {
            padding: 5px;
            border-radius: 3px;
            border: 1px solid #ddd;
        }
    </style>
</head>

<body>
    <nav class="admin-nav">
        <div class="brand">JK Shop Admin</div>
        <ul class="nav-links">
            <li><a href="admin.php">Product Management</a></li>
            <li><a href="customer_management.php">Customer Management</a></li>
            <li><a href="supplier_management.php">Supplier Management</a></li>
            <li><a href="order_history.php" class="active">Customer Order History</a></li>
        </ul>
        <a href="logout.php" class="logout">Logout</a>
    </nav>

    <div class="admin-container">
        <?php if ($message): ?>
            <div class="success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <div class="order-history">
            <h2>Customer Order History</h2>

            <?php if ($orders->num_rows > 0): ?>
                <?php while ($order = $orders->fetch_assoc()): ?>
                    <div class="order-details">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h3>Order #<?= $order['id'] ?></h3>
                                <p><strong>Customer:</strong> <?= htmlspecialchars($order['customer_name'] ?? 'Unknown') ?></p>
                                <p><strong>Email:</strong> <?= htmlspecialchars($order['customer_email'] ?? 'N/A') ?></p>
                                <p><strong>Phone:</strong> <?= htmlspecialchars($order['customer_phone'] ?? 'N/A') ?></p>
                                <?php
                                // Calculate total for this order
                                $items_query = "
                                    SELECT oi.*, p.name as product_name, p.price as product_price
                                    FROM order_items oi 
                                    LEFT JOIN products p ON oi.product_id = p.id 
                                    WHERE oi.order_id = ?
                                ";
                                $stmt = $conn->prepare($items_query);
                                $stmt->bind_param("i", $order['id']);
                                $stmt->execute();
                                $items = $stmt->get_result();

                                $order_total = 0;
                                $items_array = [];
                                while ($item = $items->fetch_assoc()) {
                                    $items_array[] = $item;
                                    $order_total += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
                                }
                                ?>
                                <p><strong>Total:</strong> Rs.<?= number_format($order_total, 2) ?>/=</p>
                                <p><strong>Order Date:</strong> <?= isset($order['order_date']) ? date('Y-m-d H:i', strtotime($order['order_date'])) : 'N/A' ?></p>
                            </div>
                            <div>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                    <select name="status" class="status-select" onchange="this.form.submit()">
                                        <option value="pending" <?= ($order['status'] ?? 'pending') == 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="processing" <?= ($order['status'] ?? 'pending') == 'processing' ? 'selected' : '' ?>>Processing</option>
                                        <option value="shipped" <?= ($order['status'] ?? 'pending') == 'shipped' ? 'selected' : '' ?>>Shipped</option>
                                        <option value="delivered" <?= ($order['status'] ?? 'pending') == 'delivered' ? 'selected' : '' ?>>Delivered</option>
                                        <option value="cancelled" <?= ($order['status'] ?? 'pending') == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" name="update_status" style="display: none;"></button>
                                </form>
                            </div>
                        </div>

                        <div class="order-items">
                            <h4>Order Items:</h4>
                            <?php if (count($items_array) > 0): ?>
                                <table class="admin-table" style="margin-top: 10px;">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($items_array as $item): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['product_name'] ?? 'Unknown Product') ?></td>
                                                <td>Rs.<?= number_format($item['price'] ?? 0, 2) ?>/=</td>
                                                <td><?= $item['quantity'] ?? 0 ?></td>
                                                <td>Rs.<?= number_format(($item['price'] ?? 0) * ($item['quantity'] ?? 0), 2) ?>/=</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>No items found for this order.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No orders found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>