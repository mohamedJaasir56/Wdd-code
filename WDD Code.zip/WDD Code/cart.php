<?php 
require 'config.php';

$message = '';
$error = '';

// Handle cart updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_cart'])) {
        foreach ($_POST['quantities'] as $product_id => $quantity) {
            $quantity = (int)$quantity;
            if ($quantity <= 0) {
                unset($_SESSION['cart'][$product_id]);
            } else {
                $_SESSION['cart'][$product_id]['quantity'] = $quantity;
            }
        }
        $message = "Cart updated successfully!";
    } elseif (isset($_POST['remove_item'])) {
        $product_id = (int)$_POST['product_id'];
        unset($_SESSION['cart'][$product_id]);
        $message = "Item removed from cart!";
    } elseif (isset($_POST['clear_cart'])) {
        $_SESSION['cart'] = [];
        $message = "Cart cleared!";
    }
}

// Calculate cart totals
$cart_total = 0;
$cart_items = $_SESSION['cart'] ?? [];
foreach ($cart_items as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart - JK Shop</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar .logo a {
            font-size: 1.8rem;
            font-weight: bold;
            color: #667eea;
            text-decoration: none;
        }
        
        .navbar .menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            margin: 0;
            padding: 0;
        }
        
        .navbar .menu a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            transition: all 0.3s ease;
        }
        
        .navbar .menu a.active,
        .navbar .menu a:hover {
            background: #667eea;
            color: white;
        }
        
        .cart-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 20px;
        }
        
        .cart-header {
            text-align: center;
            margin-bottom: 3rem;
            background: white;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .cart-header h1 {
            color: #333;
            font-size: 2.5rem;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }
        
        .cart-header i {
            color: #667eea;
        }
        
        .success {
            text-align: center;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3);
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .cart-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .cart-table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem;
            font-weight: 600;
            font-size: 1.1rem;
            text-align: left;
        }
        
        .cart-table td {
            padding: 1.5rem;
            border-bottom: 1px solid #f0f0f0;
            vertical-align: middle;
        }
        
        .cart-table tr:last-child td {
            border-bottom: none;
        }
        
        .cart-table tr:hover {
            background: #f8f9ff;
        }
        
        .cart-item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .product-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .product-name {
            font-weight: 600;
            color: #333;
            font-size: 1.1rem;
        }
        
        .quantity-input {
            width: 80px;
            padding: 0.8rem;
            border: 2px solid #e0e7ff;
            border-radius: 10px;
            text-align: center;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .quantity-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .price-text {
            font-weight: 600;
            color: #667eea;
            font-size: 1.1rem;
        }
        
        .cart-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            background: white;
            padding: 1.5rem 2rem;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .cart-total {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .cart-total::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .cart-total h3 {
            color: #333;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .total-amount {
            font-size: 3rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: bold;
            margin: 1.5rem 0;
        }
        
        .btn {
            padding: 1rem 2rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            font-size: 1rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-size: 1.2rem;
            padding: 1.2rem 3rem;
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .btn:active {
            transform: translateY(-1px);
        }
        
        .empty-cart {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .empty-cart i {
            font-size: 5rem;
            color: #e0e7ff;
            margin-bottom: 2rem;
        }
        
        .empty-cart h2 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .empty-cart p {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .cart-container {
                padding: 0 10px;
            }
            
            .cart-header h1 {
                font-size: 2rem;
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .cart-table {
                font-size: 0.9rem;
            }
            
            .cart-table th,
            .cart-table td {
                padding: 1rem 0.5rem;
            }
            
            .cart-item-image {
                width: 60px;
                height: 60px;
            }
            
            .product-info {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }
            
            .cart-actions {
                flex-direction: column;
                gap: 1rem;
            }
            
            .total-amount {
                font-size: 2rem;
            }
            
            .btn-primary {
                font-size: 1rem;
                padding: 1rem 2rem;
            }
        }
        
        @media (max-width: 480px) {
            .cart-table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            
            .cart-header {
                padding: 1.5rem;
            }
            
            .cart-total {
                padding: 2rem 1rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <a href="index.php">⚒ JK ShOP</a>
        </div>
        <ul class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="cart.php" class="active">Cart</a></li>
        </ul>
        <div class="icons">
            <a href="cart.php"><i class="fas fa-shopping-cart"></i></a>
        </div>
    </nav>

    <div class="cart-container">
        <?php if ($message): ?>
            <div class="success" style="text-align: center; padding: 15px; background: #d4edda; color: #155724; border-radius: 5px; margin-bottom: 20px;">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <div class="cart-header">
            <h1><i class="fas fa-shopping-cart"></i> Your Shopping Cart</h1>
        </div>

        <?php if (!empty($cart_items)): ?>
            <form method="POST">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $product_id => $item): ?>
                        <tr>
                            <td>
                                <div class="product-info">
                                    <img src="<?= $item['image_path'] ?>" alt="<?= $item['name'] ?>" class="cart-item-image">
                                    <span class="product-name"><?= htmlspecialchars($item['name']) ?></span>
                                </div>
                            </td>
                            <td class="price-text">Rs.<?= number_format($item['price'], 2) ?>/=</td>
                            <td>
                                <input type="number" name="quantities[<?= $product_id ?>]" value="<?= $item['quantity'] ?>" min="1" class="quantity-input">
                            </td>
                            <td class="price-text">Rs.<?= number_format($item['price'] * $item['quantity'], 2) ?>/=</td>
                            <td>
                                <button type="submit" name="remove_item" value="1" onclick="this.form.product_id.value='<?= $product_id ?>'" class="btn btn-danger" style="padding: 0.5rem 1rem;">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <input type="hidden" name="product_id" value="">
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="cart-actions">
                    <div>
                        <button type="submit" name="update_cart" class="btn btn-secondary">
                            <i class="fas fa-sync"></i> Update Cart
                        </button>
                        <button type="submit" name="clear_cart" class="btn btn-danger" onclick="return confirm('Are you sure you want to clear your cart?')">
                            <i class="fas fa-trash"></i> Clear Cart
                        </button>
                    </div>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Continue Shopping
                    </a>
                </div>
            </form>

            <div class="cart-total">
                <h3>Order Summary</h3>
                <div class="total-amount">
                    Total: Rs.<?= number_format($cart_total, 2) ?>/=
                </div>
                <a href="checkout.php" class="btn btn-primary" style="font-size: 1.2rem; padding: 15px 40px;">
                    <i class="fas fa-credit-card"></i> Proceed to Checkout
                </a>
            </div>

        <?php else: ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h2>Your cart is empty</h2>
                <p>Add some products to your cart to get started!</p>
                <a href="index.php" class="btn btn-primary">
                    <i class="fas fa-shopping-bag"></i> Start Shopping
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>